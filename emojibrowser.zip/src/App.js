import React from 'react';
import EmojiList from './EmojiList';
import './App.css';

function App() {
  return (
    <div className="App">
      <EmojiList />
    </div>
  );
}

export default App;
